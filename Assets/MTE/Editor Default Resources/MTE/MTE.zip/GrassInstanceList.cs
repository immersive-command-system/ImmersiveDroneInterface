﻿using UnityEngine;
using System.Collections.Generic;

namespace MTE
{
    public class GrassInstanceList : ScriptableObject
    {
        public List<GrassInstance> grasses;
    }

}
