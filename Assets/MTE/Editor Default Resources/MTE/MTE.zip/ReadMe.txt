﻿Those cs file is already compiled into a dll: Assets\Plugins\MTE\MTE_script.dll. Don't extract them into your project directory.

They are provided so you can customize the runtime scripts:

    1. Modify those scripts in your text editor
    2. Compile it into MTE_script.dll.
    3. Then replace the orginal one.